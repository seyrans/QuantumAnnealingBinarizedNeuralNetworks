import qubovert as qv
from qubovert import boolean_var

def latex(model, other=''):
    from IPython.display import display, Math
    text = model.pretty_str().replace('x', '').replace('z', '').replace('(', '').replace(')', '').replace('__a',
                                                                                                          'a_') + other
    display(Math(text))


def latex_qubo(model):
    from IPython.display import display, Math
    text = model.pretty_str().replace('x', r'a_').replace('z', r'').replace('(', '').replace(')', '').replace('__a',
                                                                                                              'a_')
    display(Math(text))



N = 2

# create the variables
t = {i: boolean_var('t_%d' % i) for i in range(1,N+1)}
e = 2
model = qv.PCBO()
term1 = sum(t.values()) - e
model.add_constraint_lt_zero(term1)
print('term1:')
latex(term1, '< 0')
print('model')
latex(model)
print('qubo')
latex_qubo(model.to_qubo())